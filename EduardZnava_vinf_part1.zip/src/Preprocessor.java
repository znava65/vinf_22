import java.io.*;
import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Preprocessor {

    private final ArrayList<Page> pages;
    private final Pattern IS_ANIMAL_CATEGORY_PATTERN = Pattern.compile("\\[\\[Category:.*(animal|species|mammal|fish|bird|vertebrate|invertebrate|reptile|amphibian|predator|insect).*?]]", Pattern.CASE_INSENSITIVE);
    private final Pattern IS_ANIMAL_PATTERN = Pattern.compile("genus|species|mammal|vertebrate|invertebrate|reptile|amphibian|predator|habitat", Pattern.CASE_INSENSITIVE);
    public Preprocessor() {
        this.pages = new ArrayList<>();
    }

    public void parsePages(String path) throws IOException {
        StringBuilder stringBuilder;
        BufferedReader br = new BufferedReader(new FileReader(path));
        String line;
        String content;
        Page page;
        boolean isAnimal;
        Pattern pageStartPattern = Pattern.compile("<page>");
        Pattern pageEndPattern = Pattern.compile("</page>");
        Pattern titlePattern = Pattern.compile("<title>.*?</title>");

        while ((line = br.readLine()) != null) {
            if (pageStartPattern.matcher(line).find()) {
                page = new Page();
                stringBuilder = new StringBuilder();
                do {
                    stringBuilder.append(line).append("\n");
                    // check if there is a title in the line
                    if (titlePattern.matcher(line).find()) {
                        page.setTitle(line.replaceAll(".*<title>", "").replaceAll("</title>.*", ""));
                    }
                    line = br.readLine();
                }
                while(!pageEndPattern.matcher(line).find());
                stringBuilder.append(line);
                System.out.print(page.getTitle() + " - ");
                content = stringBuilder.toString();
                isAnimal = isAnimal(clearContent(content));
                System.out.println(isAnimal);

                if (isAnimal) {
                    page.setContent(content);
                    pages.add(page);
                }
            }
        }

        if (pages.size() > 0) {
            System.out.print("\nFound animals:\n");
            for (Page p : pages) {
                System.out.println(p.getTitle());
            }
        }
    }

    private String clearContent(String content) {
        content = Pattern.compile("<page>.*?<text.*?>", Pattern.DOTALL).matcher(content).replaceAll("");
        content = Pattern.compile("</text.*?</page>.*?", Pattern.DOTALL).matcher(content).replaceAll("");
        return content;
    }

    private boolean isAnimal(String content) {
        String line;
        ArrayList<String> matches = new ArrayList<>();
        String group;

        // if there is even a single match in categories, it is an animal
        if (IS_ANIMAL_CATEGORY_PATTERN.matcher(content).find()) {
            return true;
        }

        BufferedReader br = new BufferedReader(new StringReader(content));
        try {
            while ((line = br.readLine()) != null) {
                Matcher matcher = IS_ANIMAL_PATTERN.matcher(line);
                if (matcher.find() && !matches.contains((group = matcher.group()))) {
                    matches.add(group);
//                    System.out.println(group);
                }
            }
        }
        catch (Exception e) {
            System.err.println("Error reading content");
        }

        return matches.size() >= 3;
    }
}
