import java.util.HashMap;

public abstract class CountriesLocations {
    private static final HashMap<String, String> countriesLocations = new HashMap<>();
    
    static {
        countriesLocations.put("albania", "southern europe");
    }

    public static HashMap<String, String> getCountriesLocations() {
        return countriesLocations;
    }
}
