public class Main {
    public static void main(String[] args) {
        Preprocessor preprocessor = new Preprocessor();
        try {
            preprocessor.parsePages("data/small.xml-p1p41242");
        }
        catch (Exception e) {
            System.err.println("Couldn't open file");
        }
    }
}
